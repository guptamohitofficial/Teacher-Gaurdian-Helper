from django.apps import AppConfig


class PinfoConfig(AppConfig):
    name = 'pinfo'
