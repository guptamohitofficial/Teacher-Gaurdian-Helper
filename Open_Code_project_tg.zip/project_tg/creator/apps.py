from django.apps import AppConfig


class CreatorConfig(AppConfig):
    name = 'creator'
